import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class MVGRservlet1 extends HttpServlet
{
 public void doget(HttpServletRequest req, HttpServletResponse res) throws IOException,ServletException
 {
res.setContentType("text/html");
PrintWriter.out = res.getWriter();
out.println("<html><body>");
out.printn("<h2>hello mvgr</h2>");
out.println("<body><html>");
 }
}
